import { useState } from "react";
import axios from "axios";
import '../../styles/AddVaccine.css';
import { useNavigate } from "react-router-dom";
import NavbarAdmin from "../../layout/NavbarAdmin";

function AddHospital() {
  const [hospital, setHospital] = useState({
    hospitalName: "",
    hospitalAddress: "",
    startingTime: "",
    endingTime: "",
  });

  const navigate = useNavigate();

  const onInputChange = (e) => {
    setHospital({ ...hospital, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8585/Hospital/insertHospital", hospital);
    alert("added successfully");
    navigate("/hospitals")
    setHospital({
      hospitalName: "",
      hospitalAddress: "",
      startingTime: "",
      endingTime: "",
    });
  };

  return (
    <>
    <NavbarAdmin/>
    <div className="add-vaccine">
      <div className="row">
        <div className="col-md-12 offset-md-1 border rounded p-4 mt-2 shadow">
        <h2>Add Hospital</h2>
        <form onSubmit={onSubmit}>
          <div>
            <label htmlFor="hospitalName">Hospital Name:</label>
            <input
              type="text"
              id="hospitalName"
              name="hospitalName"
              value={hospital.hospitalName}
              onChange={onInputChange}
            />
          </div>
          <div>
            <label htmlFor="hospitalAddress">Hospital Address:</label>
            <input
              type="text"
              id="hospitalAddress"
              name="hospitalAddress"
              value={hospital.hospitalAddress}
              onChange={onInputChange}
            />
          </div>
          <div>
            <label htmlFor="startingTime">Starting Time:</label>
            <input
              type="time"
              id="startingTime"
              name="startingTime"
              value={hospital.startingTime}
              onChange={onInputChange}
            />
          </div>
          <div>
            <label htmlFor="endingTime">Ending Time:</label>
            <input
              type="time"
              id="endingTime"
              name="endingTime"
              value={hospital.endingTime}
              onChange={onInputChange}
            />
          </div>
          <button type="submit">Add Hospital</button>
        </form>
      </div>
    </div>
  </div>  
    </>
  );
}

export default AddHospital;
