import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../../styles/AddVaccine.css";
import NavbarAdmin from "../../layout/NavbarAdmin";

function AdminProfile() {
  const [admin, setAdmin] = useState({
    name: "",
    password: "",
    email: "",
    phoneNumber: 0,
  });

  const obj = localStorage.getItem("userInfo");
  const { userName } = JSON.parse(obj);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAdmin = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8585/admin/getAdminByEmail/${userName}`
        );
        setAdmin(response.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchAdmin();
  }, []);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setAdmin((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.put(`http://localhost:8585/admin/updateAdminByEmail/${userName}`, admin);
      navigate("/profile");
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <NavbarAdmin />
      <div className="add-vaccine">
        <div className="row">
          <div className="col-md-12 offset-md-1 border rounded p-4 mt-2 shadow">
            <h2 className="text-center m-4">Admin Profile</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="email" className="form-label">
                  Email
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter email"
                  name="email"
                  value={admin.email}
                  onChange={handleInputChange}
                />
              </div>

              <div className="mb-3">
                <label htmlFor="password" className="form-label">
                  Password
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter password"
                  name="password"
                  value={admin.password}
                  onChange={handleInputChange}
                />
              </div>

              <button type="submit" className="btn btn-primary me-2">
                Update
              </button>
              <br></br>
              <button
                className="btn btn-secondary"
                onClick={() => navigate("/")}
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}

export default AdminProfile;
